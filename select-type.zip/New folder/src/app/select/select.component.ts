import { Component, OnInit, ViewChild } from '@angular/core';
import { MyserviceService } from '../myservice.service';
import { FormGroup, FormControl, Validator, Validators } from "@angular/forms";

@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.css']
})
export class SelectComponent implements OnInit {
 data1:any;
 @ViewChild('multiSelect',{static: false}) multiSelect;
  public form: FormGroup;
  public loadContent: boolean = false;
  public name = 'Cricketers';
  public data = [];
  public selected =[];
  public settings = {};
  public selectedItems = [];
  stateData:any={};

  constructor( private myservice:MyserviceService) { }

  ngOnInit( ) {
 this.myservice.getData().subscribe(res=>this.data1=res);

// setting and support i18n
this.settings = {
  singleSelection: false,
  idField: 'item_id',
  textField: 'country',
  enableCheckAll: true,
  allowSearchFilter: true,
  limitSelection: -1,
  clearSearchFilter: true,
  maxHeight: 197,
  itemsShowLimit: 3,
  closeDropDownOnSelection: false,
  showSelectedItemsAtTop: false,
  defaultOpen: false,
  
};
this.setForm();

}

public setForm() {
this.form = new FormGroup({
  name: new FormControl(this.data, Validators.required)
});
this.loadContent = true;
}

get f() { return this.form.controls; }

public onFilterChange(item: any) {
console.log(item);
}
public onDropDownClose(item: any) {
console.log(item);
}

public onItemSelect(item: any) {
console.log(item);
}
public onDeSelect(item: any) {
console.log(item);
}

public onSelectAll(items: any) {
console.log(items);
}
public onDeSelectAll(items: any) {
console.log(items);
}
}
