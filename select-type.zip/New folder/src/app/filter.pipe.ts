import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {


  transform(data:any, searchTerm:string): any {
    if (!data || !searchTerm) {
      return data;
  }

  return data.filter(data =>
    data.Country.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1);
}
  }